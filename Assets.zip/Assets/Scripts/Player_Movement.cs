using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Movement : MonoBehaviour
{
    public Transform transform;
    public float speed = 0.5f;

    public GameObject gameOverPanel;
    void Start()
    {
        gameOverPanel.SetActive(false);
    }
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += new Vector3(speed * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position -= new Vector3(speed * Time.deltaTime, 0, 0);
        }
        // Code for clamping left and right manually
        // if (transform.position.x < -1.73f)
        // {
        //     transform.position = new Vector3(-1.73f, transform.position.y, transform.position.z);
        // }
        // if (transform.position.x > 2.57f)
        // {
        //     transform.position = new Vector3(2.57f, transform.position.y, transform.position.z);
        // }

        // Unity Inbuilt feature
        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, -1.73f, 2.57f);
        transform.position = pos;
    }

    private void OnTriggerEnter2D(Collider2D collision)

    {
        if (collision.gameObject.tag == "Car")
        {
            Time.timeScale = 0;
            gameOverPanel.SetActive(true);
        }
    }
}